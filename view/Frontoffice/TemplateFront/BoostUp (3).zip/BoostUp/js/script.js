// script.js
$(document).ready(function() {
    $("#ajouterProjetForm").on("submit", function(event) {
        let isValid = true;

        // Effacer les erreurs précédentes
        $('#nomError').text('');
        $('#dateDebutError').text('');
        $('#dateFinError').text('');
        $('#descriptionError').text('');

        // Vérification du champ Nom
        const nom = $("#nom").val();
        if (nom.trim() === "") {
            $('#nomError').text("Le nom du projet est requis.");
            isValid = false;
        }

        // Vérification de la date de début
        const dateDebut = $("#date_debut").val();
        if (dateDebut === "") {
            $('#dateDebutError').text("La date de début est requise.");
            isValid = false;
        }

        // Vérification de la date de fin
        const dateFin = $("#date_fin").val();
        if (dateFin === "") {
            $('#dateFinError').text("La date de fin est requise.");
            isValid = false;
        }

        // Vérification de la description
        const description = $("#description").val();
        if (description.trim() === "") {
            $('#descriptionError').text("La description est requise.");
            isValid = false;
        }

        // Si la saisie est invalide, on empêche l'envoi du formulaire
        if (!isValid) {
            event.preventDefault(); // Empêche l'envoi du formulaire
        }
    });
});
