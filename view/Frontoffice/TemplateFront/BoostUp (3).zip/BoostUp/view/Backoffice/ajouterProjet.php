<?php
// Activer l'affichage des erreurs pour faciliter le débogage
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); // Affiche toutes les erreurs, avertissements et notices

// Inclure la fonction de connexion à la base de données et la classe Projet
include_once '../../config/database.php'; // Remonter de deux niveaux pour accéder à config
include_once '../../model/projet.php'; // Remonter de deux niveaux pour accéder à Model

// Vérification de la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['action']) && $_GET['action'] == 'ajouter') {
    // Récupérer les données du formulaire
    $nom_projet = $_POST['nom_projet'] ?? '';
    $date_debut = $_POST['date_debut'] ?? '';
    $date_fin = $_POST['date_fin'] ?? '';
    $description = $_POST['description'] ?? '';

    // Validation des champs
    $errors = [];

    if (empty($nom_projet)) {
        $errors[] = "Le nom du projet est obligatoire.";
    }
    if (empty($date_debut)) {
        $errors[] = "La date de début est obligatoire.";
    }
    if (empty($date_fin)) {
        $errors[] = "La date de fin est obligatoire.";
    }
    if (empty($description)) {
        $errors[] = "La description du projet est obligatoire.";
    }

    // Si pas d'erreurs, enregistrer dans la base de données
    if (empty($errors)) {
        // Créer l'objet Projet
        $projet = new Projet($nom_projet, $date_debut, $date_fin, $description);

        // Appeler la méthode pour ajouter le projet à la base de données
        $projet->ajouterProjet();

        // Afficher une alerte de succès et rediriger
        echo "<script>alert('Ajout avec succès !'); window.location.href='index.php?action=afficher';</script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Projet</title>
</head>
<body>
    <h1>Ajouter un Projet</h1>

    <?php if (!empty($errors)): ?>
        <div style="color: red;">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form id="ajouterProjetForm" method="POST" action="ajouterProjet.php?action=ajouter">
        <label for="nom_projet">Nom du Projet:</label>
        <input type="text" id="nom_projet" name="nom_projet" required><br><br>

        <label for="date_debut">Date de début:</label>
        <input type="date" id="date_debut" name="date_debut" required><br><br>

        <label for="date_fin">Date de fin:</label>
        <input type="date" id="date_fin" name="date_fin" required><br><br>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea><br><br>

        <input type="submit" value="Ajouter Projet">
    </form>
</body>
</html>

