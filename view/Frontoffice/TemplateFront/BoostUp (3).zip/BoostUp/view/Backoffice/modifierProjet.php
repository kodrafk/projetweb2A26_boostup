<?php
// Initialisation des messages d'erreur
$errorMessages = [];

// Inclusion des fichiers nécessaires
include_once('../../config/database.php');
include_once('../../model/projet.php');

// Récupérer l'ID du projet depuis l'URL ou autre méthode
$id = isset($_GET['id']) ? $_GET['id'] : null;

// Vérifier si l'ID est valide
if ($id) {
    // Récupérer les informations du projet
    $projet = Projet::getProjetById($id);
} else {
    // Rediriger si l'ID n'est pas valide
    header('Location: /BoostUp/view/Backoffice/template/Template_Luna/Projet.php');
    exit();
}

// Traitement du formulaire de modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données soumises
    $nom_projet = $_POST['nom_projet'];
    $date_debut = $_POST['date_debut'];
    $date_fin = $_POST['date_fin'];
    $description = $_POST['description'];

    // Validation des données
    if (empty($nom_projet) || empty($date_debut) || empty($date_fin) || empty($description)) {
        $errorMessages[] = "Tous les champs sont requis.";
    }

    // Vérifier si la date de fin est après la date de début
    if ($date_debut > $date_fin) {
        $errorMessages[] = "La date de début ne peut pas être après la date de fin.";
    }

    // Si pas d'erreurs, mettre à jour le projet
    if (empty($errorMessages)) {
        $updated = Projet::updateProjet($id, $nom_projet, $date_debut, $date_fin, $description);
        if ($updated) {
            header('Location: /BoostUp/view/Backoffice/template/Template_Luna/Projet.php');
            exit();
        } else {
            $errorMessages[] = "Une erreur s'est produite lors de la mise à jour.";
        }
    }
    if ($result) {
        // Si la mise à jour est réussie, rediriger vers la page principale (Projet.php)
        header('Location: /BoostUp/view/Backoffice/template/Template_Luna/Projet.php');
        exit(); // N'oubliez pas d'utiliser exit après header() pour éviter que du code ne soit exécuté après la redirection
    } else {
        echo "Erreur lors de la mise à jour du projet.";
    }
} else {
    echo "Données manquantes dans le formulaire!";

}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Projet</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Modifier le Projet</h2>

        <?php if (!empty($errorMessages)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($errorMessages as $message): ?>
                        <li><?php echo $message; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Formulaire de modification du projet -->
        <form action="modifierProjet.php?id=<?php echo $id; ?>" method="POST">
            <div class="form-section">
                <h5 class="section-title">Informations du Projet</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="nom_projet" class="form-label">Nom du Projet</label>
                        <input type="text" id="nom_projet" name="nom_projet" class="form-control" value="<?php echo isset($projet['nom_projet']) ? $projet['nom_projet'] : ''; ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label for="date_debut" class="form-label">Date de début</label>
                        <input type="date" id="date_debut" name="date_debut" class="form-control" value="<?php echo isset($projet['date_debut']) ? $projet['date_debut'] : ''; ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label for="date_fin" class="form-label">Date de fin</label>
                        <input type="date" id="date_fin" name="date_fin" class="form-control" value="<?php echo isset($projet['date_fin']) ? $projet['date_fin'] : ''; ?>" required>
                    </div>

                    <div class="col-12">
                        <label for="description" class="form-label">Description</label>
                        <textarea id="description" name="description" class="form-control" rows="3" required><?php echo isset($projet['description']) ? $projet['description'] : ''; ?></textarea>
                    </div>
                </div>

                <!-- Boutons d'action -->
                <div class="d-flex justify-content-between mt-4">
                    <a href="projet.php" class="btn btn-secondary">Annuler</a>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check me-1"></i> Enregistrer
                    </button>
                </div>
            </div>

            <!-- Champ caché pour l'ID du projet -->
            <input type="hidden" name="id_projet" value="<?php echo $id; ?>">
        </form>
    </div>

    <!-- Bootstrap JS (optional, for better performance) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
