<?php 
// Correct path from edit.php to header.php
$basePath = dirname(__DIR__, 2); // Goes up two levels to htdocs/events/
$headerPath = $basePath . '/views/layouts/header.php';

if (file_exists($headerPath)) {
    require_once $headerPath;
} else {
    die('Header file not found at: ' . $headerPath);
}
?>

<h2>Edit Event</h2>

<form method="POST" action="index.php?action=edit&controller=event&id=<?= htmlspecialchars($event['id'] ?? '') ?>">
    <div>
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" value="<?= htmlspecialchars($event['title'] ?? '') ?>" required>
    </div>
    
    <div>
        <label for="event_date">Date:</label>
        <input type="date" id="event_date" name="event_date" value="<?= htmlspecialchars($event['event_date'] ?? '') ?>" required>
    </div>
    
    <div>
        <label for="location">Location:</label>
        <input type="text" id="location" name="location" value="<?= htmlspecialchars($event['location'] ?? '') ?>" required>
    </div>
    
    <div>
        <label for="link">Link (optional):</label>
        <input type="url" id="link" name="link" value="<?= htmlspecialchars($event['link'] ?? '') ?>">
    </div>
    
    <div class="confirmation-dialog">
        <button type="submit" name="confirm" value="yes" class="btn btn-primary">Update Event</button>
        <a href="index.php?action=list&controller=event" class="btn btn-danger">Cancel</a>
    </div>
</form>

<?php 
$footerPath = $basePath . '/views/layouts/footer.php';
if (file_exists($footerPath)) {
    require_once $footerPath;
} else {
    die('Footer file not found at: ' . $footerPath);
}
?>