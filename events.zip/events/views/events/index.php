<?php 
require_once __DIR__ . '/../../views/layouts/header.php'; 
?>

<table>
    <thead>
        <tr>
            <th>Title</th>
            <th>Date</th>
            <th>Location</th>
            <th>Link</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($events as $event): ?>
        <tr>
            <td><?= htmlspecialchars($event['title']) ?></td>
            <td><?= date('d/m/Y', strtotime($event['event_date'])) ?></td>
            <td><?= htmlspecialchars($event['location']) ?></td>
            <td>
                <?php if ($event['link']): ?>
                    <a href="<?= htmlspecialchars($event['link']) ?>" target="_blank">Join</a>
                <?php else: ?>
                    N/A
                <?php endif; ?>
            </td>
            <td>
                <a href="index.php?action=edit&controller=event&id=<?= $event['id'] ?>" class="btn btn-warning">Edit</a>
                <a href="index.php?action=delete&controller=event&id=<?= $event['id'] ?>" class="btn btn-danger">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php 
require_once __DIR__ . '/../../views/layouts/footer.php'; 
?>