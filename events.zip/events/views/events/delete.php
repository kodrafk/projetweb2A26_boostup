<?php 
// Correct path to header.php from delete.php
$headerPath = __DIR__ . '/../layouts/header.php';
if (file_exists($headerPath)) {
    require_once $headerPath;
} else {
    die('Header file not found at: ' . $headerPath);
}
?>

<h2>Delete Event</h2>

<div>
    <p><strong>Title:</strong> <?= htmlspecialchars($event['title'] ?? '') ?></p>
    <p><strong>Date:</strong> <?= isset($event['event_date']) ? date('d/m/Y', strtotime($event['event_date'])) : '' ?></p>
    <p><strong>Location:</strong> <?= htmlspecialchars($event['location'] ?? '') ?></p>
    <?php if (!empty($event['link'])): ?>
        <p><strong>Link:</strong> <a href="<?= htmlspecialchars($event['link']) ?>" target="_blank"><?= htmlspecialchars($event['link']) ?></a></p>
    <?php endif; ?>
</div>

<form method="POST" action="index.php?action=delete&controller=event&id=<?= $event['id'] ?? '' ?>">
    <div class="confirmation-dialog">
        <p>Are you sure you want to delete this event?</p>
        <button type="submit" name="confirm" value="yes" class="btn btn-danger">Yes</button>
        <button type="submit" name="confirm" value="no" class="btn">No</button>
    </div>
</form>

<?php 
$footerPath = __DIR__ . '/../layouts/footer.php';
if (file_exists($footerPath)) {
    require_once $footerPath;
} else {
    die('Footer file not found at: ' . $footerPath);
}
?>