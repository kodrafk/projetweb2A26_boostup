<?php 
// Use absolute path from the document root
$baseDir = dirname(__DIR__, 2); // Goes up to htdocs/events/
$headerPath = $baseDir . '/views/layouts/header.php';

if (file_exists($headerPath)) {
    require_once $headerPath;
} else {
    die('Header file not found at: ' . $headerPath);
}
?>

<h2>Create New Event</h2>

<form method="POST" action="index.php?action=create&controller=event">
    <div>
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required>
    </div>
    
    <div>
        <label for="event_date">Date:</label>
        <input type="date" id="event_date" name="event_date" required>
    </div>
    
    <div>
        <label for="location">Location:</label>
        <input type="text" id="location" name="location" required>
    </div>
    
    <div>
        <label for="link">Link (optional):</label>
        <input type="url" id="link" name="link">
    </div>
    
    <button type="submit" class="btn btn-primary">Create Event</button>
    <a href="index.php?action=index&controller=event" class="btn">Cancel</a>
</form>

<?php 
$footerPath = $baseDir . '/views/layouts/footer.php';
if (file_exists($footerPath)) {
    require_once $footerPath;
} else {
    die('Footer file not found at: ' . $footerPath);
}
?>